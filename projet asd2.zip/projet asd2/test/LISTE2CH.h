#ifndef LISTE2CH_H_INCLUDED
#define LISTE2CH_H_INCLUDED

#include "ELTPRIM2.h"

typedef struct structnoeud2{
    ELEMENT2 info;
    struct structnoeud2 *suivant;
}structnoeud2,*NOEUD2;

typedef struct{
    NOEUD2 tete;
    int lg;
}lastruct2,*LISTE2;

#endif // LISTE2CH_H_INCLUDED
