#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ELTPRIM1.h"
#define ELEMENT_VIDE NULL

ELEMENT1 elementCreer1(){
    ELEMENT1 e;
    e=(ELEMENT1)malloc(sizeof(CLES));
    return e;
}
void elementAfficher1(ELEMENT1 elt){
    printf("\n n=%d   ||   b=%d \n",elt->a,elt->b);
}
void elementCopier1(ELEMENT1 *e1,ELEMENT1 e2){
    (*e1)->a=e2->a;
    (*e1)->b=e2->b;
}
void elementAffecter1(ELEMENT1 *e1,ELEMENT1 e2){
    *e1=e2;
}
int elementComparer1(ELEMENT1 e1,ELEMENT1 e2){
    if(e1->a==e2->a && e1->b==e2->b){
        return 0;
    }
    else{
        return 1;
    }
}
void elementDetruire1(ELEMENT1 e1){
    free(e1);
}
void elementLire1(ELEMENT1 *e1){
    printf("donnez un entier n: ");
    scanf("%d",&(*e1)->a);
    printf("donnez un entier b: ");
    scanf("%d",&(*e1)->b);
}
