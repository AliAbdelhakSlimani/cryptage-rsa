#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "ELTPRIM.h"
#include "ELTPRIM1.h"
#include "LISTPRIM.h"
#include "PILEPRIM.h"
#include "ELTPRIM2.h"
#include "LISTEPRIM2.h"
int choisir (int tab[1000]){
    int p;
    int alea;
    do{
        alea=rand();
    }while(alea>1000);
    p=tab[alea];
    return p;
}
int taillef(FILE *f){
   char chaine[1000];
    int taille=0;
     while(fgets(chaine,sizeof(chaine),f)!=NULL){
        taille++;
    }
    return taille;
}
int saisirparcours(int taillefi){
    system("powershell -c (New-Object Media.SoundPlayer 'bienvenue (2).wav').PlaySync();");
    int i;
    do{
            if(i<1 || i>taillefi){
                printf("\n\n\033[0;31m  soyez prudent svp\033[0m\n");
                system("powershell -c (New-Object Media.SoundPlayer 'bienvenue (1).wav').PlaySync();");
            }
        printf("donnez un entier entre 1 et %d : ",taillefi);
        scanf("%d",&i);

    }while(i>taillefi || i<1);
    return i;
}
int exist(int n,int phi,Pile pi){
    int i;
    ELEMENT1 elt=elementCreer();
    elt->a=n;
    elt->b=phi;
    NOEUD1 e1=NoeudCreer1(elt);
    NOEUD1 e;
    e=pi->tete;
    int test=0;
    while(e!=NULL && test==0){
       if( elementComparer1(elt,e->info)==0){
        test=1;
       }
       e=e->suivant;
    }
    return test;
}
int chercher(int phi) {
    int e;
    do {

        printf("donner l'exposant e : avec e est entre 1 et %d et premier avec %d :",phi,phi);
        scanf("%d", &e);
        if(pgcd(e, phi) != 1 || e <= 1 || e >= phi){
            system("powershell -c (New-Object Media.SoundPlayer 'bienvenue (1).wav').PlaySync();");
            printf("\n\n\033[0;31m soyez prudent \033[0m\n");
        }
    } while (pgcd(e, phi) != 1 || e <= 1 || e >= phi);

    return e;

}
int pgcd(int a, int b) {
   int q, r1, r2, r;

    if (a > b)
    {
        r1 = a;
        r2 = b;
    }
    else {
        r1 = b;
        r2 = a;
    }

    while (r2 > 0)
    {
        q = r1 / r2;
        r = r1 - q * r2;
        r1 = r2;
        r2 = r;
    }


    return r1;
}
int inverse(int a, int b) {
    int inv;
    int q, r, r1 = a, r2 = b, t, t1 = 0, t2 = 1;

    while (r2 > 0) {
        q = r1 / r2;
        r = r1 - q * r2;
        r1 = r2;
        r2 = r;

        t = t1 - q * t2;
        t1 = t2;
        t2 = t;
    }

    if (r1 == 1) {
        inv = t1;
    }

    if (inv < 0) {
        inv = inv + a;
    }

    return inv;
}
int mod_exp(int a, int b, int n) {
	long long x = 1, y = a;

	while (b > 0) {
		if (b % 2 == 1)
			x = (x * y) % n;
		y = (y * y) % n; // Squaring the base
		b /= 2;
	}

	return x % n;
}
int chiffrement (int m, int e ,int n){
    return mod_exp(m, e, n);
}
int combien (int chif){
    char ch[100];
    sprintf(ch,"%d",chif);
    return strlen(ch);
}
int premier(int x) {
    int ok = 1;
    if (x < 2) {
        ok = 0;
    } else {
        int i = 2;
        while (i * i <= x && ok == 1) {
            if (x % i == 0) {
                ok = 0;
            } else
                i++;
        }
    }
    return ok;
}
ELEMENT2 chiffrement_du_chaine(int n , int e , char chaine[1000],int t,int d){
   ELEMENT2 elt;
    elt->chaine = (char **)malloc(strlen(chaine) * sizeof(char *));
    if (elt->chaine == NULL) {
        printf( "Erreur d'allocation m�moire pour le tableau de pointeurs\n");
    }
    for(int i=0;i<t;i++){
        char c=chaine[i];
        int m = (int)c;
        int chif = chiffrement(m, e, n);
        int ta=combien(chif);
        elt->chaine[i]=(char *)malloc(sizeof(char)*(ta)+1);
        if(!elt->chaine[i]){
            printf("espace insuffisante\n");
        }
        sprintf(elt->chaine[i],"%d",chif);
        elt->chaine[i][ta]=NULL;
    }

    elt->chaine[t]=(char *)malloc(sizeof(char)*10);
    elt->chaine[t]=NULL;
    return elt;
    }
int dechiffrement(int chif ,int d,int n){
    return mod_exp(chif,d, n);
}
ELEMENT dechiffrement_du_chaine(int n,int d,char **chaine_chif,int t){
    ELEMENT e=elementCreer();
    int i=0;
    char tab[t];
    while(i<t){
        int dechif= dechiffrement(atoi(chaine_chif[i]), d, n);
        char c=(char)dechif;

        tab[i]=c;
        i++;
    }
    tab[t]=NULL;
    strcpy(e->chaine,tab);
    return e;
}

int main()
{

    //REMPLISSAGE DE LA LISTE DEPUIS UNE FICHIER
    LISTE2 L2=listeCreer2();
    FILE *f;
    int taillefi;
    int t;

    f=fopen("fichier.txt","r");
    if(f==NULL){
        perror("\n\033[0;31m erreur lors de l'ouverture \033[0m\n");
        return 1;
    }

    taillefi=taillef(f);
    t=saisirparcours(taillefi);
    fclose(f);
    LISTE L;
    L=listeCreer();
    f=fopen("fichier.txt","r");
    char ch[1000];
    ELEMENT e;
    for(int i=1;i<=t;i++){
        e=elementCreer();
        fgets(ch,sizeof(ch),f);
        strcpy(e->chaine,ch);
        inserer(L,e,i);
    }
    fclose(f);
    printf("\n\033[0;33m------------------voici les chaines a cryptee : -------------------------\033[0m\n");
    listeAfficher(L);
    //REMPLISSAGE TABLEAU DES ENTIERS ALEATOIRES
    int tab[1000];
    int i;
    srand(time(NULL));
    for(i=1;i<=1000;i++){
        tab[i]=rand();
        while(!premier(tab[i])){
            tab[i]=rand();
        }
    }


    Pile pi,pp;
    pi=PileCreer();
    pp=PileCreer();
    LISTE L3=listeCreer();
    ELEMENT1 cle,clepr;
    int q,p,n,phi,ex,d;
    for(int i=1;i<=t;i++){
        cle=elementCreer1();
        clepr=elementCreer1();
        do{
            p=choisir(tab);
            q=choisir(tab);
            n=p*q;
            phi=(p-1)*(q-1);
            ex=chercher(phi);
        }while(exist(n,ex,pi));
        printf("\033[0;33m%d\033[0m\n",ex);
        d=inverse(phi,ex);
        int taille=strlen(recuperer(L,i)->chaine)-1;
        inserer2(L2,chiffrement_du_chaine(n,ex,recuperer(L,i)->chaine,strlen(recuperer(L,i)->chaine)-1,d),i);
        inserer(L3,dechiffrement_du_chaine(n,d,recuperer2(L2,i)->chaine,taille),i);
        cle->a=n;
        cle->b=ex;
        Empiler(pi,cle);
        clepr->a=n;
        clepr->b=d;
        Empiler(pp,clepr);
    }
    system("powershell -c (New-Object Media.SoundPlayer 'crypt.wav').PlaySync();");
    printf("\n\033[0;33m------------------voici les chaines apres le cryptage : -------------------------\033[0m\n");
    listeAfficher2(L2);
    system("powershell -c (New-Object Media.SoundPlayer 'd�crypt.wav').PlaySync();");
    printf("\n\033[0;33m------------------voici les chaines apres le decryptage : -------------------------\033[0m\n");
    listeAfficher(L3);

    return 0;
}
