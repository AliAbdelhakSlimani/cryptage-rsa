#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ELTPRIM2.h"
#define ELEMENT_VIDE NULL

ELEMENT2 elementCreer2(){
    ELEMENT2 e;
    e=(ELEMENT2)malloc(sizeof(CHDOUBLE));
    return e;
}
void elementAfficher2(ELEMENT2 elt){
    printf("\n");
    int taille=0;
    while(elt->chaine[taille]!=NULL){
        printf("%s",elt->chaine[taille]);
        taille++;
    }
    printf("\n");
}
void elementCopier2(ELEMENT2 *e1,ELEMENT2 e2){
    int taille=0;
    while((e2)->chaine[taille]!=NULL){
        (*e1)->chaine[taille]=(char *)malloc(sizeof(char)*1);
        strcpy((*e1)->chaine[taille],e2->chaine[taille]);
        taille++;
    }

}
void elementAffecter2(ELEMENT2 *e1,ELEMENT2 e2){
    *e1=e2;
}
int elementComparer2(ELEMENT2 e1,ELEMENT2 e2){
    int comp;
    int taille;
    while(e1->chaine[taille]!=NULL){
        taille++;
    }
    int taille1=0;
    while(e2->chaine[taille]!=NULL){
        taille++;
    }
    if(taille!=taille1){
        return 1;
    }
    else{
        int talka=0;
         int i=0;
        while(e1->chaine[i]!=NULL && talka==0){
            if(strcmp(e1->chaine[i],e2->chaine[i])==0){
                i++;
            }
            else{
                talka=1;
            }
        }
        return talka;
    }
}
void elementDetruire2(ELEMENT2 e1){
    int i=0;
    while(e1->chaine[i]!=NULL){
        free(e1->chaine[i]);
        i++;
    }
    free(e1);
}
void elementLire2(ELEMENT2 *e1 ){
    int nb;
    printf("\ncombien de chaines de caracteres tu veux lire : ");
    scanf("%d",&nb);
    for(int i=0;i<nb;i++){
        (*e1)->chaine[i]=(char *)malloc(sizeof(char)*20);
        printf("donnez une chaine : ");
        fgets((*e1)->chaine[i],sizeof((*e1)->chaine[i]),stdin);
    }

}
