#ifndef LISTPTR_H_INCLUDED
#define LISTPTR_H_INCLUDED

#include "ELTPRIM.h"

typedef struct structnoeud{
    ELEMENT info;
    struct structnoeud *suivant;
}structnoeud,*NOEUD;

typedef struct{
    NOEUD tete;
    int lg;
}lastruct,*LISTE;

#endif // LISTPTR_H_INCLUDED
