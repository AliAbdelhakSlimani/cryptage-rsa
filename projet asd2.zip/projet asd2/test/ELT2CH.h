#ifndef ELT2CH_H_INCLUDED
#define ELT2CH_H_INCLUDED

typedef struct{
    char ** chaine;
}CHDOUBLE,*ELEMENT2;

#endif // ELT2CH_H_INCLUDED
