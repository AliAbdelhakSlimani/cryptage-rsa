#ifndef _PILPRIM_H_INCLUDED
#define _PILPRIM_H_INCLUDED
#include "ELTPRIM1.h"
#include "PILESDD.h"
NOEUD1 NoeudCreer1(ELEMENT1);
void NoeudDetruire1(NOEUD1);
Pile PileCreer(void);
void PileDetruire(Pile);
int EstVide(Pile);
int EstSaturee(Pile);
int PileTaille(Pile);
ELEMENT1 Sommet(Pile);
int Empiler(Pile, ELEMENT1);
ELEMENT1 Depiler(Pile);
void PileAfficher(Pile);
Pile PileCopier(Pile);
int PileComparer(Pile, Pile);
#endif
