#ifndef LISTPRIM_H_INCLUDED
#define LISTPRIM_H_INCLUDED

#include "LISTSDD.h"
#include "ELTPRIM.h"

LISTE listeCreer();
void listeDetruire(LISTE);
void listeAfficher(LISTE);
int inserer(LISTE,ELEMENT,int);
int supprimer(LISTE,int);
int listeTaille(LISTE);
int estVide(LISTE);
int estSaturee(LISTE);
LISTE listeCopier(LISTE);
int listeComparer(LISTE,LISTE);
ELEMENT recuperer(LISTE,int);

#endif // LISTPRIM_H_INCLUDED
