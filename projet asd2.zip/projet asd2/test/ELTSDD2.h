#ifndef ELTSDD2_H_INCLUDED
#define ELTSDD2_H_INCLUDED

#include "ELT2CH.h"

#endif // ELTSDD2_H_INCLUDED
