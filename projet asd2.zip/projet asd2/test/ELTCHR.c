#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ELTPRIM.h"
#define ELEMENT_VIDE NULL

ELEMENT elementCreer(){
    ELEMENT e;
    e=(ELEMENT)malloc(sizeof(CHAINE));
    return e;
}
void elementAfficher(ELEMENT elt){
    printf("\n la chaine est : %s \n",elt->chaine);
}
void elementCopier(ELEMENT *e1,ELEMENT e2){
    strcpy((*e1)->chaine,e2->chaine);
}
void elementAffecter(ELEMENT *e1,ELEMENT e2){
    *e1=e2;
}
int elementComparer(ELEMENT e1,ELEMENT e2){
    return (strcmp(e1->chaine,e2->chaine));
}
void elementDetruire(ELEMENT e1){
    free(e1);
}
void elementLire(ELEMENT *e1){
    printf("donnez une chaine : ");
    fgets((*e1)->chaine,sizeof((*e1)->chaine),stdin);
}
