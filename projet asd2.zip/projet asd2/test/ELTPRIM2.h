#ifndef ELTPRIM2_H_INCLUDED
#define ELTPRIM2_H_INCLUDED


#include "ELTSDD2.h"

ELEMENT2 elementCreer2(void);
int elementComparer2(ELEMENT2,ELEMENT2);
void elementLire2(ELEMENT2* );
void elementAfficher2(ELEMENT2);
void elementCopier2(ELEMENT2*,ELEMENT2);
void elementAffecter2(ELEMENT2*,ELEMENT2);
void elementDetruire2(ELEMENT2);


#endif // ELTPRIM2_H_INCLUDED
