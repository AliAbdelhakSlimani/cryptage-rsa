#ifndef LISTEPRIM2_H_INCLUDED
#define LISTEPRIM2_H_INCLUDED

#include "LISTESDD2.h"
#include "ELTPRIM2.h"

LISTE2 listeCreer2();
void listeDetruire2(LISTE2);
void listeAfficher2(LISTE2);
int inserer2(LISTE2,ELEMENT2,int);
int supprimer2(LISTE2,int);
int listeTaille2(LISTE2);
int estVide2(LISTE2);
int estSaturee2(LISTE2);
LISTE2 listeCopier2(LISTE2);
int listeComparer2(LISTE2,LISTE2);
ELEMENT2 recuperer2(LISTE2,int);

#endif // LISTEPRIM2_H_INCLUDED
