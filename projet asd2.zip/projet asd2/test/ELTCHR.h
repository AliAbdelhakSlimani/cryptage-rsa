#ifndef ELTCHR_H_INCLUDED
#define ELTCHR_H_INCLUDED

typedef struct {
    char chaine[1000];
}CHAINE,*ELEMENT;
#endif // ELTCHR_H_INCLUDED
