#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "LISTEPRIM2.h"

void noeudDetruire2(NOEUD2 n){
    elementDetruire2(n->info);
    free(n);
}
NOEUD2 noeudCreer2(ELEMENT2 e){
    NOEUD2 n;
    n=(NOEUD2)malloc(sizeof(structnoeud2));
    if(!n){
        printf("\n espace insuffisante pour creer un noeud \n");
    }
    else{
        elementAffecter2(&n->info,e);
        n->suivant=NULL;
    }
    return n;
}
int listeTaille2(LISTE2 L){
    return L->lg;
}
LISTE2 listeCreer2(){
    LISTE2 L;
    L=(LISTE2)malloc(sizeof(lastruct2));
    if(!L){
        printf("\n espace insuffisante pour la creation de la liste \n");
    }
    else{
        L->lg=0;
        L->tete=NULL;
    }
    return L;
}
int estSaturee2(LISTE2 L){
    NOEUD2 temp;
    int saturee=1;
    temp=(NOEUD2)malloc(sizeof(structnoeud2));
    if(temp!=NULL){
        saturee=0;
        free(temp);
    }
    return saturee;
}
void listeDetruire2(LISTE2 L){
    NOEUD2 p,q;
    q=L->tete;
    for(int i=1;i<=listeTaille2(L);i++){
        p=q;
        q=q->suivant;
        noeudDetruire2(p);
    }
    free(L);
}
int inserer2(LISTE2 L,ELEMENT2 elt,int pos){
    int succee=1;
    NOEUD2 n,p,q;
    if(estSaturee2(L)){
        printf("\n m�moire insuffisante pour ajouter un �l�ment a la liste \n");
        succee=0;
    }
    else{
        if(pos<1 || pos>listeTaille2(L)+1){
            printf("\n position invalide \n");
            succee=0;
        }
        else{

            n=noeudCreer2(elt);
            if(pos==1){
                n->suivant=L->tete;
                L->tete=n;
            }
            else{
                int i;
                q=L->tete;
                for(i=1;i<pos;i++){
                    p=q;
                    q=p->suivant;
                }
                p->suivant=n;
                n->suivant=q;

            }
            L->lg++;
        }
    }
    return succee;
}
int estVide2(LISTE2 L) {
    return (L->lg == 0);
}
int supprimer2 (LISTE2 L, int pos ){
    int i;
    int succee=1;
    NOEUD2 p, q;
    if (estVide2(L)) {
        printf ("\nListe vide\n");
        succee=0;
    }
    else {
        if ((pos < 1) || (pos > L->lg)){
            printf ("\nPosition invalide");
            succee=0;
        }

        else{
            q = L->tete;
            if (pos == 1)
            L->tete=L->tete->suivant;
            else {
                for (i=1; i<pos; i++) {
                    p = q;
                    q = q->suivant;
                }
                p->suivant=q->suivant;
            }
            noeudDetruire2(q);
            (L->lg)--;

        }
    }
    return succee;
}
ELEMENT2 recuperer2(LISTE2 L, int pos) {
    ELEMENT2 elt= elementCreer2();
    int i;
    NOEUD2 p;
    if (estVide2(L))
        printf ("\nListe vide");
    else {
        if ((pos < 1) || (pos > L->lg))
            printf ("\nPosition invalide");
        else {
            p= L->tete;
            for (i=1; i<pos; i++)
                p = p->suivant;
            elementAffecter2(&elt,p->info);
        }

    }
    return(elt);
}
void listeAfficher2(LISTE2 L){
    int i;
    NOEUD2 p;
    p= L->tete;
    for(i = 1;i <= L->lg; i++) {
        elementAfficher2(p->info);
        p= p->suivant;
    }
}
LISTE2 listeCopier2(LISTE2 L){
    LISTE2 LR = listeCreer2();
    int i;
    ELEMENT2 elt;
    for(i = 1;i <= L->lg; i++) {
        elt=elementCreer2();
        elementCopier2(&elt, recuperer2(L,i));
        inserer2(LR,elt, i);
    }
    return LR;
}
int listeComparer2 (LISTE2 L1,LISTE2 L2 )
{
    int test= 1;
    int i=1;
    if (listeTaille2(L1) != listeTaille2(L2)) test= 0;
    while ((i<=listeTaille2(L1)) && (test)) {
        if(elementComparer2(recuperer2(L1,i),recuperer2(L2,i))!=0)
            test=0;
        i++;
    }
    return test;
}
