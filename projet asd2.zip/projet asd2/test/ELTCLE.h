#ifndef ELTCLE_H_INCLUDED
#define ELTCLE_H_INCLUDED

typedef struct {
    int a;
    int b;
}CLES,*ELEMENT1;

#endif // ELTCLE_H_INCLUDED
