#ifndef ELTPRIM_H_INCLUDED
#define ELTPRIM_H_INCLUDED

#include "ELTSDD.h"

ELEMENT elementCreer(void);
int elementComparer(ELEMENT,ELEMENT);
void elementLire(ELEMENT*);
void elementAfficher(ELEMENT);
void elementCopier(ELEMENT*,ELEMENT);
void elementAffecter(ELEMENT*,ELEMENT);
void elementDetruire(ELEMENT);

#endif // ELTPRIM_H_INCLUDED
